# SkyCast Weather

A responsive weather dashboard built with HTML, CSS and JavaScript.

## Features
- Search weather by city worldwide
- Current conditions, feels-like temperature and high/low
- Humidity, wind speed, UV index and rain probability
- Hourly forecast and 7-day forecast
- Optional current-location weather
- Responsive glassmorphism design
- No API key required (Open-Meteo)

## Run locally
1. Download and extract `SkyCast-Weather.zip`.
2. Open `index.html` in a browser.
3. Keep an internet connection for live weather data.

## Publish on GitHub Pages
1. Create a new **public** GitHub repository (for example, `skycast-weather`).
2. Upload `index.html` and `README.md` to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait a minute or two. Your site link will appear in the Pages section, usually:
   `https://YOUR-USERNAME.github.io/skycast-weather/`

## Data source
Weather and geocoding data are provided by [Open-Meteo](https://open-meteo.com/).
